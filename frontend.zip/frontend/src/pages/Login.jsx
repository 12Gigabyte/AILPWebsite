import { useState } from 'react';

export default function Login({ onNavigate, onClose }) {

    const [isLoginMode, setIsLoginMode] = useState(true);

    const [name, setName] = useState('');
    const [institution, setInstitution] = useState('');
    const [dob, setDob] = useState('');

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);

    const [message, setMessage] = useState({ text: '', type: '' });
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();

        setMessage({ text: '', type: '' });
        setIsLoading(true);

        const endpoint = isLoginMode ? '/api/login' : '/api/signup';

        const payload = isLoginMode
            ? { email, password }
            : { name, institution, dob, email, password };

        try {

            const response = await fetch(`http://localhost:8000${endpoint}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            const data = await response.json();
            console.log("BACKEND RESPONSE:", data);
            console.log("BACKEND RESPONSE:", data);

            if (response.ok) {

                // LOGIN SUCCESS
                if (isLoginMode) {

                    localStorage.setItem('isAuthenticated', 'true');
                    
                    // SAVE FULL USER OBJECT
                    console.log("BACKEND RESPONSE:", data);
                    localStorage.setItem('user', JSON.stringify(data.user));

                    onNavigate('dashboard');

                } else {

                    // SIGNUP SUCCESS
                    setIsLoginMode(true);

                    setPassword('');

                    setMessage({
                        text: 'Account created successfully! Please log in.',
                        type: 'success'
                    });
                }

            } else {

                setMessage({
                    text: data.detail || 'Authentication failed.',
                    type: 'error'
                });

            }

        } catch (err) {

            setMessage({
                text: 'Cannot connect to backend server.',
                type: 'error'
            });

        } finally {

            setIsLoading(false);

        }
    };

    return (

        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex justify-center items-center p-4 z-50 animate-fade-in">

            <div className="max-w-md w-full bg-white rounded-[2rem] shadow-2xl border border-slate-100 p-8 md:p-10 relative overflow-hidden transition-all duration-300">

                {/* CLOSE BUTTON */}
                <button
                    onClick={onClose}
                    className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
                >
                    ✕
                </button>

                {/* HEADER */}
                <div className="text-center mb-8 mt-2">
                    <h1 className="text-3xl font-extrabold text-indigo-600 mb-2 tracking-tight">
                        SynapseAI
                    </h1>

                    <p className="text-slate-500 text-sm font-medium">
                        {isLoginMode
                            ? 'Welcome back! Please enter your details.'
                            : 'Create an account to save your progress.'
                        }
                    </p>
                </div>

                {/* MESSAGE */}
                {message.text && (
                    <div
                        className={`mb-6 p-3 border rounded-xl text-sm text-center font-medium
                        ${message.type === 'success'
                                ? 'bg-emerald-50 border-emerald-100 text-emerald-600'
                                : 'bg-red-50 border-red-100 text-red-600'
                            }`}
                    >
                        {message.text}
                    </div>
                )}

                <form onSubmit={handleSubmit} className="flex flex-col gap-5">

                    {/* NAME */}
                    {!isLoginMode && (
                        <div className="flex flex-col gap-1.5">
                            <label className="text-sm font-semibold text-slate-700 ml-1">
                                Full Name
                            </label>

                            <input
                                type="text"
                                required
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="px-4 py-3 border border-slate-200 rounded-2xl bg-slate-50"
                                placeholder="Alex Johnson"
                            />
                        </div>
                    )}

                    {/* EMAIL */}
                    <div className="flex flex-col gap-1.5">

                        <label className="text-sm font-semibold text-slate-700 ml-1">
                            Email
                        </label>

                        <input
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="px-4 py-3 border border-slate-200 rounded-2xl bg-slate-50"
                            placeholder="you@example.com"
                        />

                    </div>

                    {/* PASSWORD */}
                    <div className="flex flex-col gap-1.5">

                        <label className="text-sm font-semibold text-slate-700 ml-1">
                            Password
                        </label>

                        <div className="relative">

                            <input
                                type={showPassword ? 'text' : 'password'}
                                required
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full px-4 py-3 border border-slate-200 rounded-2xl bg-slate-50"
                                placeholder="••••••••"
                            />

                            <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-4 top-1/2 -translate-y-1/2"
                            >
                                👁
                            </button>

                        </div>

                    </div>

                    {/* SIGNUP ONLY FIELDS */}
                    {!isLoginMode && (
                        <>

                            {/* INSTITUTION */}
                            <div className="flex flex-col gap-1.5">

                                <label className="text-sm font-semibold text-slate-700 ml-1">
                                    Educational Institute / Workplace
                                </label>

                                <input
                                    type="text"
                                    required
                                    value={institution}
                                    onChange={(e) => setInstitution(e.target.value)}
                                    className="px-4 py-3 border border-slate-200 rounded-2xl bg-slate-50"
                                    placeholder="Harvard University"
                                />

                            </div>

                            {/* DOB */}
                            <div className="flex flex-col gap-1.5">

                                <label className="text-sm font-semibold text-slate-700 ml-1">
                                    Date of Birth
                                </label>

                                <input
                                    type="date"
                                    required
                                    value={dob}
                                    onChange={(e) => setDob(e.target.value)}
                                    className="px-4 py-3 border border-slate-200 rounded-2xl bg-slate-50"
                                />

                            </div>

                        </>
                    )}

                    {/* SUBMIT */}
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="mt-4 w-full bg-indigo-600 text-white py-3.5 rounded-full text-sm font-semibold hover:bg-indigo-700 transition-all"
                    >
                        {isLoading
                            ? 'Loading...'
                            : isLoginMode
                                ? 'Sign In'
                                : 'Create Account'
                        }
                    </button>

                    {/* TOGGLE */}
                    <div className="text-center mt-2">

                        <p className="text-sm text-slate-500">

                            {isLoginMode
                                ? "Don't have an account? "
                                : "Already have an account? "
                            }

                            <button
                                type="button"
                                onClick={() => {
                                    setIsLoginMode(!isLoginMode);
                                    setMessage({ text: '', type: '' });
                                }}
                                className="text-indigo-600 font-bold hover:underline"
                            >
                                {isLoginMode ? 'Sign up' : 'Log in'}
                            </button>

                        </p>

                    </div>

                </form>

            </div>

        </div>
    );
}